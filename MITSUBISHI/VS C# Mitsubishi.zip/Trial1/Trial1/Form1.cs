﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trial1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             int returncode;
             try
             {
                 axActUtlType1.ActLogicalStationNumber = 1;
                 returncode = axActUtlType1.Open();
                 if (returncode == 0)
                 {
                     status.AppendText("Connected");
                 }
             }
             catch
             { 
             }
        }

        private void read_Click(object sender, EventArgs e)
        {
            int ReturnCode;				
            String DeviceName = "D0";		
            short[] DeviceValue;		    
            System.String[] arrData;	   
            DeviceValue = new short[1];
            try
            {

                ReturnCode = axActUtlType1.ReadDeviceBlock2(DeviceName, 1, out DeviceValue[0]);
                data.AppendText("  Value of D0 = ");
                data.AppendText(DeviceValue[0].ToString());
            }
                

            catch
            {
            }

        }
    }
}
